local currentIndex = 1

Citizen.CreateThread(function()
    while true do
        Wait(Config.Interval * 1000)

        if Config.EnableNotifs then
            local msg = Config.Messages[currentIndex]
            TriggerClientEvent('deezz:showNotif', -1, msg)

            currentIndex = currentIndex + 1
            if currentIndex > #Config.Messages then
                currentIndex = 1
            end
        end
    end
end)


RegisterNetEvent('deezz:sendToDiscord')
AddEventHandler('deezz:sendToDiscord', function(message)
    local webhook = Config.WebhookURL  -- Config.lua

    if webhook == nil or webhook == "" then 
    print("^1[BugReporter] Erreur : Le webhook Discord n'est pas configuré dans config.lua^7")    
        return 
    end

    local embed = {
        {
            ["color"] = Config.Embedcouleur, -- Config.lua
            ["title"] = Config.EmbedTitre,  -- Config.lua
            ["description"] = message,  -- Config.lua
            ["footer"] = {
                ["text"] = Config.NomServeur,  -- Config.lua
            }
        }
    }

    PerformHttpRequest(webhook, function(err, text, headers) end, 'POST', json.encode({
        username = Config.NomServeur,
        embeds = embed
    }), { ['Content-Type'] = 'application/json' })
end)